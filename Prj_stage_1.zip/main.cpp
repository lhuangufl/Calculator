/*
 * main.cpp
 *
 *  Created on: Jun 19, 2015
 *      Author: franklyn
 *
 *  Finished on: July 6, 2015
 */

#include <iostream>
#include <stack>
#include <string>
#include <vector>
#include <ctype.h>
#include "Str2Vector.h"
#include "ShuntYard.h"


int main() {

	std::vector<std::string>		InString;
	std::vector<std::string>		OuString;
	std::string						str_tmp;

	Str2Vector						_StrVect;
	ShuntYard						shuntyard;

	std::cout << "> ";
	std::getline(std::cin, str_tmp);
	//str_tmp = "67 + ( 32 / 8 ) * 3 rt 8";
	//obtain the vector of strings based on spaces between any values and operators
	
	InString = _StrVect.getVector(str_tmp);
	OuString = shuntyard.Shunt(InString);

	for (unsigned int i = 0; i != OuString.size(); i++)
	{
		std::cout << OuString[i] << " ";
	}
	return 0;
}

