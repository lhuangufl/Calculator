#include "ShuntYard.h"


ShuntYard::ShuntYard()
{
}

ShuntYard::~ShuntYard()
{
}

bool ShuntYard::is_number(const std::string& s)
{
	std::string::const_iterator it = s.begin();
	while (it != s.end() && isdigit(*it)) ++it;
	return !s.empty() && it == s.end();
}

bool ShuntYard::isOperat(std::string token)
{
	if (token == "+" || token == "-" || token == "*"
			|| token == "/" || token == "^" || token == "rt")
	{
		return true;
	}
	else return false;
}

bool ShuntYard::token_rank(std::string tokenA, std::string tokenB)
{
	// Checking ADDITION AND SUBTRACTION
	if (tokenA == "+" || tokenA == "-")
	{
		if (tokenB == "-" || tokenB == "+"){ return true; }
		if (tokenB == "*" || tokenB == "/"){ return true; }
		if (tokenB == "^" || tokenB == "rt"){ return true; }
		if (tokenB == "("){ return false; }
	}
	//  checking MULTIPLICATION AND DIVISION
	if (tokenA == "*" || tokenA == "/")
	{
		if (tokenB == "-" || tokenB == "+"){ return false; }
		if (tokenB == "*" || tokenB == "/"){ return true; }
		if (tokenB == "^" || tokenB == "rt"){ return true; }
		if (tokenB == "("){ return false; }
	}
	//  checking EXPONENTIATION
	if (tokenA == "^" || tokenA == "rt")
	{
		if (tokenB == "-" || tokenB == "+"){ return false; }
		if (tokenB == "*" || tokenB == "/"){ return false; }
		if (tokenB == "^" || tokenB == "rt"){ return false; }
		if (tokenB == "("){ return false; }
	}
}

bool ShuntYard::token_IsLParen(std::string token)
{
	if (token == "(")
	{
		return true;
	}
	else return false;
}

bool ShuntYard::token_IsRParen(std::string token)
{
	if (token == ")")
	{
		return true;
	}
	else return false;
}

std::vector<std::string> ShuntYard::Shunt(std::vector<std::string>& InStr)
{
	for (unsigned int i = 0; i != InStr.size(); i++)
	{
		if (is_number(InStr[i]))
		{
			OuString.push_back(InStr[i]);
		}
		else if (isOperat(InStr[i]))
		{
			if (OperatorStack.empty())
			{
				OperatorStack.push(InStr[i]);
			}
			else if (token_rank(InStr[i], OperatorStack.top()))
			{
				OuString.push_back(OperatorStack.top());
				OperatorStack.pop();

				OperatorStack.push(InStr[i]);
			}
			else if (!token_rank(InStr[i], OperatorStack.top()))
			{
				OperatorStack.push(InStr[i]);
			}
		}
		else if (token_IsLParen(InStr[i]))
		{
			OperatorStack.push(InStr[i]);
		}
		else if (token_IsRParen(InStr[i]))
		{
			while (!token_IsLParen(OperatorStack.top()))
			{
				OuString.push_back(OperatorStack.top());
				OperatorStack.pop();
			}
			if (token_IsLParen(OperatorStack.top())) { OperatorStack.pop(); }
		}
	}

	while (!OperatorStack.empty())
	{
		OuString.push_back(OperatorStack.top());
		OperatorStack.pop();
	}
	return OuString;
}
